// config.js - Configuration file for database connection and other settings

let config = {
  APP_DB_HOST: "database-1.ct820c48yjy5.us-east-1.rds.amazonaws.com",       // RDS endpoint (host)
  APP_DB_USER: "admin",       // Database username
  APP_DB_PASSWORD: "azeP1907902",   // Database password
  APP_DB_NAME: "database-1",       // Database name
};

// AWS SDK to interact with Secrets Manager
var AWS = require('aws-sdk');
var client = new AWS.SecretsManager({
    region: "us-east-1"  // Ensure the region matches where your RDS and Secrets Manager are located
});

const secretName = "Mydbsecret";  // Name of the secret stored in AWS Secrets Manager

// Fetch the secret value from Secrets Manager
client.getSecretValue({SecretId: secretName}, function(err, data) {
    if (err) {
        // If error occurs, use default values
        config.APP_DB_HOST = "localhost";  // Fallback host value
        config.APP_DB_NAME = "STUDENTS";  // Fallback database name
        config.APP_DB_PASSWORD = "student12";  // Fallback password
        config.APP_DB_USER = "nodeapp";  // Fallback user
        console.log('Secrets not found. Proceeding with default values..');
    }
    else {
        // If the secret exists, parse and use it
        if ('SecretString' in data) {
            secret = JSON.parse(data.SecretString);
            for(const envKey of Object.keys(secret)) {
                process.env[envKey] = secret[envKey]; // Save secret values to environment variables
                if (envKey == 'user') {
                    config.APP_DB_USER = secret[envKey];
                } else if (envKey == 'password') {
                    config.APP_DB_PASSWORD = secret[envKey];
                } else if (envKey == 'host') {
                    config.APP_DB_HOST = secret[envKey];
                } else if (envKey == 'db') {
                    config.APP_DB_NAME = secret[envKey];
                }
            }
        }
    }
});

// Load environment variables into the config object (overriding defaults with ENV vars)
Object.keys(config).forEach(key => {
    if (process.env[key] === undefined) {
        console.log(`[NOTICE] Value for key '${key}' not found in ENV, using default value. See app/config/config.js`);
    } else {
        config[key] = process.env[key];
    }
});

module.exports = config;

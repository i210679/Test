const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const supplier = require("./app/controller/supplier.controller"); // Ensure this path is correct
const mysql = require("mysql2");  // MySQL Node.js client
const app = express();
const mustacheExpress = require("mustache-express");
const favicon = require("serve-favicon");

// Load the configuration
const config = require("./app/config/config");  // Ensure this path is correct

// Set up the MySQL connection
const connection = mysql.createConnection({
  host: config.APP_DB_HOST,  // From config.js or Secrets Manager
  user: config.APP_DB_USER,  // From config.js or Secrets Manager
  password: config.APP_DB_PASSWORD,  // From config.js or Secrets Manager
  database: config.APP_DB_NAME,  // From config.js or Secrets Manager
  port: 3306,  // MySQL default port
});

// Test MySQL connection
connection.connect((err) => {
  if (err) {
    console.error("Error connecting to the database:", err.stack);
    return;
  }
  console.log("Connected to the database as id " + connection.threadId);
});

// Parse requests of content-type: application/json
app.use(bodyParser.json());
// Parse requests of content-type: application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());
app.options("*", cors());
app.engine("html", mustacheExpress());
app.set("view engine", "html");
app.set("views", __dirname + "/views");
app.use(express.static("public"));
app.use(favicon(__dirname + "/public/img/favicon.ico"));

// List all the students
app.get("/", (req, res) => {
  res.render("home", {});
});

app.get("/students/", supplier.findAll); // Ensure supplier.findAll is properly defined
// Show the add supplier form
app.get("/supplier-add", (req, res) => {
  res.render("supplier-add", {});
});
// Receive the add supplier POST
app.post("/supplier-add", supplier.create);
// Show the update form
app.get("/supplier-update/:id", supplier.findOne);
// Receive the update POST
app.post("/supplier-update", supplier.update);
// Receive the POST to delete a supplier
app.post("/supplier-remove/:id", supplier.remove);

// Handle 404
app.use(function (req, res, next) {
  res.status(404).render("404", {});
});

// Set port, listen for requests
const app_port = process.env.APP_PORT || 80;
app.listen(app_port, () => {
  console.log(`Server is running on port ${app_port}.`);
});
